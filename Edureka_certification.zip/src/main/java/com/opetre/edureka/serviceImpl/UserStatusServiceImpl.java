package com.opetre.edureka.serviceImpl;

import com.opetre.edureka.dao.UserStatusDao;
import com.opetre.edureka.entity.UserStatus;
import com.opetre.edureka.service.UserStatusService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserStatusServiceImpl implements UserStatusService {

    @Autowired
    UserStatusDao statusDao;

    @Override
    public List<UserStatus> getUserStatuses() {
        return statusDao.getUserStatuses();
    }
}
