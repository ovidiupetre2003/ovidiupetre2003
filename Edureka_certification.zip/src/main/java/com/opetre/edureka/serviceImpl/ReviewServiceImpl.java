package com.opetre.edureka.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opetre.edureka.Constant;
import com.opetre.edureka.dao.ReviewDao;
import com.opetre.edureka.entity.Review;
import com.opetre.edureka.service.ReviewService;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	ReviewDao reviewDao;

	private String errorMessage;

	public boolean createReview(Review review) {
		if (review.getAdded_by() == null || review.getReview().isEmpty()) {
			errorMessage = Constant.ERR_ALL_FIELDS;
			return false;
		} else {
			reviewDao.createReview(review);
			return true;
		}

	}

	public boolean updateReview(Review review) {
		if (review.getAdded_by() == null || review.getReview().isEmpty()) {
			errorMessage = Constant.ERR_ALL_FIELDS;
			return false;
		} else {
			reviewDao.updateReview(review);
			return true;
		}
	}

	public List<Review> getAllReviewesByProductId(Integer productId) {
		return reviewDao.getAllReviewesByProductId(productId);
	}

	@Override
	public String showErrorMessage() {
		return errorMessage;
	}

	@Override
	public boolean deleteReviewById(Integer reviewId) {
		// TODO Auto-generated method stub
		return false;
	}
}
