package com.opetre.edureka.serviceImpl;

import com.opetre.edureka.dao.UserRoleDao;
import com.opetre.edureka.entity.UserRole;
import com.opetre.edureka.service.UserRoleService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserRoleServiceImpl implements UserRoleService {

    @Autowired
    UserRoleDao userRoleDao;

    @Override
    public List<UserRole> getUserRoles() {
        return userRoleDao.getUserRoles();
    }
}
