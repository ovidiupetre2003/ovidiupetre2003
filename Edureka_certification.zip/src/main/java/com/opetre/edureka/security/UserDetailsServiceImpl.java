package com.opetre.edureka.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.opetre.edureka.dao.UserDao;
import com.opetre.edureka.entity.User;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	private String userPassword;
	private Integer userRole;
	private Integer userStatus;

	@Autowired
	UserDao userDao;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		User user = userDao.getUserByUsername(username);

		if (user != null) {
			userPassword = user.getPassword();
			userRole = user.getRole();
			userStatus = user.getStatus();

			if (userStatus == 1) {
				if (userRole == 1) {
					authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
					return new UserLogin(username, userPassword, authorities, user.getId());
				}
				if (userRole == 2) {
					authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
					return new UserLogin(username, userPassword, authorities, user.getId());
				}
			}
			throw new UsernameNotFoundException("Account is inactive!");
		}
		throw new UsernameNotFoundException("User not found!");
	}
}
