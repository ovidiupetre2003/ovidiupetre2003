package com.opetre.edureka.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.opetre.edureka.Constant;

@Controller
public class HomeController {
	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = Constant.HOME_URL, method = RequestMethod.GET)
	public String home() {
		return Constant.PRODUCTS_REDIRECT_URL;
	}

}
