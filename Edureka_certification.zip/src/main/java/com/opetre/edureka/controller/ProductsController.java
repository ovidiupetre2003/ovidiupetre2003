package com.opetre.edureka.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.opetre.edureka.Constant;
import com.opetre.edureka.dto.ProductSearch;
import com.opetre.edureka.entity.Product;
import com.opetre.edureka.entity.Review;
import com.opetre.edureka.security.UserLogin;
import com.opetre.edureka.serviceImpl.ProductServiceImpl;
import com.opetre.edureka.serviceImpl.ReviewServiceImpl;

@Controller
public class ProductsController {

	@Autowired
	ProductServiceImpl productService;
	@Autowired
	ReviewServiceImpl reviewService;

	private String errorMessage;

	/**
	 * 
	 * @param model
	 * @param productSearch
	 * @return
	 */
	@RequestMapping(value = Constant.PRODUCTS_URL, method = RequestMethod.GET)
	public String listProducts(Model model, @ModelAttribute("ProductSearch") ProductSearch productSearch) {

		List<Product> listProducts = productService.getAllProducts(productSearch.getName(), productSearch.getPrice(),
				productSearch.getType(), productSearch.getQuantity());
		model.addAttribute(Constant.PRODUCTS, listProducts);
		model.addAttribute("productsUrl", Constant.PRODUCTS_URL);
		model.addAttribute("productAddUrl", Constant.PRODUCT_ADD_URL);
		model.addAttribute("productEditNoIdUrl", Constant.PRODUCT_EDIT_NO_ID_URL);
		model.addAttribute("productDeleteNoIdUrl", Constant.PRODUCT_DELETE_NO_ID_URL);

		return Constant.PRODUCTS;
	}

	/**
	 * 
	 * @param product
	 * @param model
	 * @return
	 */
	@Secured("ROLE_ADMIN")
	@RequestMapping(value = Constant.PRODUCT_URL, method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("product") Product product, Model model) {
		boolean successCreateProduct;
		boolean successEditProduct;
		if (product.getId() == null) {
			successCreateProduct = productService.createProduct(product);
			if (successCreateProduct) {
				return Constant.PRODUCTS_REDIRECT_URL;
			} else {
				errorMessage = productService.showErrorMessage();
				model.addAttribute(Constant.ERROR_MESSAGE, errorMessage);
				return addProduct(product, model);
			}
		} else {
			successEditProduct = productService.updateProduct(product);
			if (successEditProduct) {
				return Constant.PRODUCTS_REDIRECT_URL;
			} else {
				errorMessage = productService.showErrorMessage();
				model.addAttribute(Constant.ERROR_MESSAGE, errorMessage);
				return editProduct(product.getId(), model);
			}
		}
	}

	/**
	 * 
	 * @param product
	 * @param model
	 * @return
	 */
	@Secured("ROLE_ADMIN")
	@RequestMapping(Constant.PRODUCT_ADD_URL)
	public String addProduct(@ModelAttribute("product") Product product, Model model) {
		model.addAttribute("productEditNoIdUrl", Constant.PRODUCT_EDIT_NO_ID_URL);
		model.addAttribute("productUrl", Constant.PRODUCT_URL);
		return Constant.PRODUCT_FORM_URL;
	}

	/**
	 * 
	 * @param id
	 * @param pageId
	 * @param model
	 * @return
	 */
	@RequestMapping(Constant.REVIEW)
	public String seeReviews(@PathVariable Integer id, @PathVariable Integer pageId, Model model) {
		List<Review> reviews = reviewService.getAllReviewesByProductId(id);
		model.addAttribute("pagesIterator", reviews.size() / 3);
		if (pageId == 1) {
			model.addAttribute("beginRow", 0);
			model.addAttribute("endRow", 2);
		} else {
			model.addAttribute("beginRow", ((pageId - 1) * 3));
			model.addAttribute("endRow", pageId * 3 - 1);
		}
		model.addAttribute("reviewes", reviews);
		model.addAttribute("productUrl", Constant.PRODUCT_URL);
		model.addAttribute("product", productService.getProductById(id));
		model.addAttribute("pageId", pageId);
		return Constant.PRODUCT;
	}

	/**
	 * 
	 * @param review
	 * @param product_id
	 * @param pageId
	 * @param model
	 * @return
	 */
	@PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	@RequestMapping(Constant.REVIEW_ADD_URL)
	public String addReview(@ModelAttribute("review") Review review, @PathVariable Integer product_id,
			@PathVariable Integer pageId, Model model) {

		model.addAttribute("productId", product_id);
		model.addAttribute("pageId", pageId);
		model.addAttribute("reviewAddUrl", Constant.REVIEW_ADD_URL);
		return Constant.REVIEW_FORM_URL;
	}

	/**
	 * 
	 * @param review
	 * @param product_id
	 * @param pageId
	 * @param model
	 * @return
	 */
	@PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	@RequestMapping(value = Constant.REVIEW_ADD_URL, method = RequestMethod.POST)
	public String saveReview(@ModelAttribute("review") Review review, @PathVariable Integer product_id,
			@PathVariable Integer pageId, Model model) {

		boolean successCreateReview;
		String loggedUserName = ((UserLogin) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUsername();
		review.setAdded_by(loggedUserName);
		// review.setProduct_id(productId);
		successCreateReview = reviewService.createReview(review);
		if (successCreateReview) {
			return "redirect:/product/review/" + review.getProduct_id() + "/" + pageId;
		} else {
			errorMessage = reviewService.showErrorMessage();
			model.addAttribute(Constant.ERROR_MESSAGE, errorMessage);
			return Constant.REVIEW_RELOAD;
		}
	}

	/**
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@Secured("ROLE_ADMIN")
	@RequestMapping(Constant.PRODUCT_EDIT_URL)
	public String editProduct(@PathVariable Integer id, Model model) {
		model.addAttribute("productEditNoIdUrl", Constant.PRODUCT_EDIT_NO_ID_URL);
		model.addAttribute("productUrl", Constant.PRODUCT_URL);
		model.addAttribute("product", productService.getProductById(id));
		return Constant.PRODUCT_FORM_URL;
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	@Secured("ROLE_ADMIN")
	@RequestMapping(Constant.PRODUCT_DELETE_URL)
	public String deleteProduct(@PathVariable Integer id) {
		productService.deleteProductById(id);
		return Constant.PRODUCTS_REDIRECT_URL;
	}
}
