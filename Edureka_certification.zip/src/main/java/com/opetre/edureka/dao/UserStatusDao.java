package com.opetre.edureka.dao;

import java.util.List;

import com.opetre.edureka.entity.UserStatus;

public interface UserStatusDao {
    List<UserStatus> getUserStatuses();
}
