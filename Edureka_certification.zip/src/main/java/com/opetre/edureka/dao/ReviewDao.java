package com.opetre.edureka.dao;

import java.util.List;

import com.opetre.edureka.entity.Review;

public interface ReviewDao {
    List<Review> getAllReviewesByProductId(Integer productId);
    void updateReview(Review review);
    void createReview(Review review);

}
