package com.opetre.edureka.dao;


import java.util.List;

import com.opetre.edureka.entity.UserRole;

public interface UserRoleDao {
    List<UserRole> getUserRoles();
}
