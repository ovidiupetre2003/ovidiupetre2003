package com.opetre.edureka.service;

import java.util.List;

import com.opetre.edureka.entity.UserStatus;

public interface UserStatusService {

    List<UserStatus> getUserStatuses();
}
