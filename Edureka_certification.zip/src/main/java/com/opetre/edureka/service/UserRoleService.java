package com.opetre.edureka.service;

import java.util.List;

import com.opetre.edureka.entity.UserRole;

public interface UserRoleService {
    List<UserRole> getUserRoles();
}
