package com.opetre.edureka.service;

import java.util.List;

import com.opetre.edureka.entity.Review;

public interface ReviewService {
	boolean createReview(Review review);

	boolean deleteReviewById(Integer reviewId);

	List<Review> getAllReviewesByProductId(Integer productId);

	String showErrorMessage();
}
