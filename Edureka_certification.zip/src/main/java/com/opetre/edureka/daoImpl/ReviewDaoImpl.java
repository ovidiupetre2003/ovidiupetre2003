package com.opetre.edureka.daoImpl;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.opetre.edureka.dao.ReviewDao;
import com.opetre.edureka.entity.Product;
import com.opetre.edureka.entity.Review;

@Repository
public class ReviewDaoImpl implements ReviewDao {

	@Autowired
	SessionFactory sessionFactory;

	public List<Review> getAllReviewesByProductId(Integer productId) {
		Session session = this.sessionFactory.openSession();
		Criteria crit = session.createCriteria(Review.class);
		crit.add(Restrictions.eq("product_id", productId));

		List<Review> allReviews = crit.list();
		return allReviews;
	}

	@Transactional
	public void updateReview(Review review) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.update(review);
		tx.commit();
		session.close();
	}

	@Transactional
	@PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	public void createReview(Review review) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(review);
		tx.commit();
		session.close();
	}

}
